import datetime

def get_current_time_utc():
  return datetime.datetime.utcnow()

def get_current_time():
  return datetime.datetime.now()


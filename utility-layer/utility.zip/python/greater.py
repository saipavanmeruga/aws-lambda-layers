def greet(message):
  print(f"Welcome {message}")

